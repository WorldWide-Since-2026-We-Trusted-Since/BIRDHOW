# MOTHERSHIP: IMPLEMENTIERUNGS-LEITFADEN
## Schritt-für-Schritt-Anleitung vom VPS zum produktiven System

---

## VORWORT

Dieser Leitfaden führt Sie durch den kompletten Setup-Prozess der Mothership Cloud Infrastructure. Von der Auswahl des richtigen VPS-Providers über die Installation aller Komponenten bis hin zur KI-Integration und dem ersten produktiven Deployment.

**Zielgruppe:** System-Administratoren, DevOps-Engineers, technisch versierte Unternehmer

**Voraussetzungen:**
- Grundlegende Linux-Kenntnisse
- SSH-Zugang zu einem Server
- Domainbesitz mit DNS-Verwaltung
- ~4-6 Stunden Zeit für Initial-Setup

**Kosten (monatlich):**
- VPS: €10-50 (je nach Spec)
- Domains: €10-15 pro Domain/Jahr
- Optional: CloudFlare Pro €20/Monat

---

## PHASE 1: VPS-AUSWAHL & VORBEREITUNG

### 1.1 VPS-Provider-Vergleich

| Provider | CPU | RAM | Storage | Traffic | Preis/Monat | Empfehlung |
|----------|-----|-----|---------|---------|-------------|------------|
| **Hetzner** | 4 vCPU | 16GB | 160GB SSD | 20TB | €16 | ⭐⭐⭐⭐⭐ Beste Preis/Leistung |
| **Contabo** | 6 vCPU | 16GB | 400GB SSD | 32TB | €15 | ⭐⭐⭐⭐ Viel Storage |
| **DigitalOcean** | 4 vCPU | 16GB | 320GB SSD | 5TB | $84 | ⭐⭐⭐ Einfach, aber teuer |
| **Linode** | 4 vCPU | 16GB | 320GB SSD | 5TB | $80 | ⭐⭐⭐ Solide Performance |
| **Vultr** | 4 vCPU | 16GB | 320GB SSD | 4TB | $72 | ⭐⭐⭐ Global verfügbar |

**Empfehlung für Start:** Hetzner CPX31 (€16/Monat)

**Kritische Anforderungen:**
✅ Root-Zugriff (kein Managed Hosting)  
✅ Port 25 freigeschaltet (für E-Mail)  
✅ Reverse-DNS konfigurierbar  
✅ EU-Standort (für DSGVO-Compliance)  

### 1.2 VPS bestellen & initialisieren

**Bestellung bei Hetzner (Beispiel):**

1. Account erstellen: https://accounts.hetzner.com/signUp
2. Cloud-Projekt anlegen
3. Server hinzufügen:
   - **Location:** Falkenstein (Deutschland)
   - **Image:** Ubuntu 22.04
   - **Type:** CPX31 (4 vCPU, 16 GB RAM, 160 GB NVMe)
   - **Networking:** IPv4 + IPv6
   - **SSH-Key:** Public-Key hochladen (wichtig!)
   
4. Server starten

**Erster Zugriff:**

```bash
# SSH-Verbindung
ssh root@YOUR-SERVER-IP

# System aktualisieren
apt update && apt upgrade -y

# Hostname setzen
hostnamectl set-hostname mothership.yourdomain.com

# Reboot
reboot
```

### 1.3 DNS-Konfiguration

**Bei Ihrem Domain-Registrar (z.B. Namecheap, Cloudflare):**

```
; A-Records
@                   A     93.184.216.34    ; Haupt-Domain
mail                A     93.184.216.34    ; Mail-Server
api                 A     93.184.216.34    ; API-Endpoint
cloud               A     93.184.216.34    ; Cloud-Storage
git                 A     93.184.216.34    ; Git-Server
*                   A     93.184.216.34    ; Wildcard für alle Subdomains

; MX-Record (E-Mail)
@                   MX    10 mail.trust.it.

; SPF (Spam-Protection)
@                   TXT   "v=spf1 mx a ~all"

; DMARC
_dmarc              TXT   "v=DMARC1; p=quarantine; rua=mailto:dmarc@trust.it"

; Reverse-DNS (bei Hetzner-Console konfigurieren)
PTR 93.184.216.34       mail.trust.it
```

**Wichtig:** DNS-Propagation kann 1-24h dauern!

---

## PHASE 2: BASIS-SYSTEM-INSTALLATION

### 2.1 Security-Hardening

```bash
# Firewall aktivieren
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 25/tcp
ufw allow 465/tcp
ufw allow 587/tcp
ufw allow 993/tcp
ufw enable

# Fail2Ban installieren
apt install fail2ban -y

# Fail2Ban konfigurieren
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = 22
logpath = /var/log/auth.log
EOF

systemctl restart fail2ban

# Automatische Updates
apt install unattended-upgrades -y
dpkg-reconfigure -plow unattended-upgrades
```

### 2.2 Docker & Docker Compose installieren

```bash
# Docker über offizielles Skript
curl -fsSL https://get.docker.com | sh

# Docker aktivieren
systemctl enable docker
systemctl start docker

# Docker Compose Plugin
apt install docker-compose-plugin -y

# Test
docker --version
docker compose version
```

### 2.3 ZFS installieren (Storage-Management)

```bash
# ZFS-Utils installieren
apt install zfsutils-linux -y

# Bei Hetzner: Zusatz-Volume bestellen (optional)
# Oder: Hauptfestplatte partitionieren

# Prüfe verfügbare Disks
lsblk

# Beispiel-Output:
# NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
# sda      8:0    0   160G  0 disk 
# ├─sda1   8:1    0   159G  0 part /
# └─sda2   8:2    0     1G  0 part [SWAP]
# sdb      8:16   0     1T  0 disk           <-- Zusatz-Volume

# ZFS Pool erstellen (auf sdb - Beispiel)
# ACHTUNG: Ersetzt alle Daten auf sdb!
zpool create -f storage-pool /dev/sdb

# Prüfen
zpool status

# Datasets für Layer erstellen
zfs create storage-pool/mail-data
zfs create storage-pool/cloud-storage
zfs create storage-pool/git-repos
zfs create storage-pool/docker-volumes
zfs create storage-pool/backups

# Compression aktivieren
zfs set compression=lz4 storage-pool

# Mount-Punkte
mkdir -p /mnt/storage-pool
zfs set mountpoint=/mnt/storage-pool/mail-data storage-pool/mail-data
zfs set mountpoint=/mnt/storage-pool/cloud-storage storage-pool/cloud-storage
zfs set mountpoint=/mnt/storage-pool/git-repos storage-pool/git-repos
zfs set mountpoint=/mnt/storage-pool/docker-volumes storage-pool/docker-volumes
zfs set mountpoint=/mnt/storage-pool/backups storage-pool/backups

# Auto-Snapshot-Tool installieren
apt install zfs-auto-snapshot -y

# Snapshot-Konfiguration
# Täglich um 2 Uhr
zfs set com.sun:auto-snapshot=true storage-pool
```

### 2.4 Docker-Netzwerke erstellen

```bash
# Public Network (Internet-zugänglich)
docker network create \
  --driver bridge \
  --subnet 172.18.0.0/24 \
  --gateway 172.18.0.1 \
  mothership-public

# Private Network (nur intern)
docker network create \
  --driver bridge \
  --subnet 172.19.0.0/24 \
  --gateway 172.19.0.1 \
  --internal \
  mothership-private

# Mail Network (isoliert für E-Mail)
docker network create \
  --driver bridge \
  --subnet 172.20.0.0/24 \
  --gateway 172.20.0.1 \
  mothership-mail

# Verifizieren
docker network ls
```

---

## PHASE 3: MAIL-INFRASTRUKTUR (MAILCOW)

### 3.1 Mailcow herunterladen & konfigurieren

```bash
# Verzeichnis erstellen
cd /opt
git clone https://github.com/mailcow/mailcow-dockerized
cd mailcow-dockerized

# Mailcow-Config generieren
./generate_config.sh

# WICHTIG: Folgende Fragen beantworten:
# Mail server hostname (FQDN): mail.trust.it
# Timezone: Europe/Berlin

# Erweiterte Konfiguration
nano mailcow.conf

# Anpassen:
MAILCOW_HOSTNAME=mail.trust.it
MAILCOW_PASS_SCHEME=BLF-CRYPT
HTTP_PORT=8080
HTTP_BIND=127.0.0.1
HTTPS_PORT=8443
HTTPS_BIND=127.0.0.1
SKIP_LETS_ENCRYPT=y    # Wir nutzen Nginx Proxy Manager
API_KEY=CHANGE-THIS-TO-SECURE-KEY
API_ALLOW_FROM=172.18.0.0/24,127.0.0.1

# Storage auf ZFS umbiegen
nano docker-compose.yml

# Suche nach "vmail-vol-1:" und ersetze:
# volumes:
#   vmail-vol-1:
#     driver: local
#     driver_opts:
#       type: none
#       o: bind
#       device: /mnt/storage-pool/mail-data

# Netzwerk anpassen
# Ersetze das default-Network durch:
# networks:
#   default:
#     external: true
#     name: mothership-mail
```

### 3.2 Mailcow starten

```bash
# Erste Initialisierung (dauert 5-10 Minuten)
docker compose pull
docker compose up -d

# Logs verfolgen
docker compose logs -f

# Warten auf "mailcow is now fully up and running"

# Admin-Zugang testen
# URL: http://YOUR-SERVER-IP:8080
# User: admin
# Pass: moohoo (SOFORT ÄNDERN!)
```

### 3.3 Mailcow-Erstkonfiguration

**Über Web-UI (http://YOUR-SERVER-IP:8080):**

1. **Login:** admin / moohoo
2. **Passwort ändern:** System → Konfiguration → Admin-Password
3. **Domain hinzufügen:**
   - Configuration → Mail Setup → Domains → Add domain
   - Domain: `trust.it`
   - Max. Mailboxes: 100
   - Max. Quota: 10240 MB
   - Add

4. **Erstes Postfach erstellen:**
   - Configuration → Mail Setup → Mailboxes → Add mailbox
   - Username: admin
   - Domain: trust.it
   - Name: Administrator
   - Quota: 5120 MB
   - Password: [SICHERES PASSWORT]
   - Active: ✓

5. **DKIM-Key generieren:**
   - Configuration → Mail Setup → Domains → trust.it → DKIM
   - Generate
   - **Wichtig:** DKIM Public Key kopieren und als DNS TXT-Record hinzufügen:
     ```
     dkim._domainkey.trust.it  TXT  "v=DKIM1; k=rsa; p=MIGfMA0G..."
     ```

6. **API-Key notieren:**
   - System → Configuration → API → Generate API Key
   - **Sicher speichern!** Wird später für Mothership-API benötigt

---

## PHASE 4: REVERSE PROXY (NGINX PROXY MANAGER)

### 4.1 Nginx Proxy Manager installieren

```bash
# Verzeichnis erstellen
mkdir -p /opt/nginx-proxy
cd /opt/nginx-proxy

# Docker Compose Config
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  nginx-proxy:
    image: 'jc21/nginx-proxy-manager:latest'
    container_name: mothership-proxy
    restart: unless-stopped
    ports:
      - '80:80'
      - '443:443'
      - '81:81'
    environment:
      DB_SQLITE_FILE: "/data/database.sqlite"
    volumes:
      - npm-data:/data
      - npm-letsencrypt:/etc/letsencrypt
    networks:
      mothership-public:
        ipv4_address: 172.18.0.2

volumes:
  npm-data:
  npm-letsencrypt:

networks:
  mothership-public:
    external: true
EOF

# Starten
docker compose up -d

# Logs prüfen
docker logs -f mothership-proxy
```

### 4.2 Nginx Proxy Manager konfigurieren

**Zugriff:** http://YOUR-SERVER-IP:81

**Initial-Login:**
- Email: `admin@example.com`
- Password: `changeme`

**SOFORT ändern nach erstem Login!**

**Proxy Hosts anlegen:**

1. **Mailcow-WebUI:**
   - Domain: `mail.trust.it`
   - Scheme: `https`
   - Forward-Host: `172.20.0.2` (Mailcow-Nginx-Container)
   - Forward-Port: `443`
   - ✓ Block Common Exploits
   - ✓ WebSocket Support
   - SSL-Tab:
     - ✓ Request new SSL Certificate
     - ✓ Force SSL
     - ✓ HTTP/2 Support
     - ✓ HSTS Enabled
     - Email: your-email@trust.it

2. **Cloud (Nextcloud - vorbereitet für später):**
   - Domain: `cloud.trust.it`
   - Forward-Host: `172.18.0.30`
   - Forward-Port: `80`
   - SSL: Wie oben

3. **Git (Gitea - vorbereitet):**
   - Domain: `git.trust.it`
   - Forward-Host: `172.18.0.40`
   - Forward-Port: `3000`
   - SSL: Wie oben

4. **API (Mothership - vorbereitet):**
   - Domain: `api.trust.it`
   - Forward-Host: `172.18.0.5`
   - Forward-Port: `5000`
   - SSL: Wie oben
   - Custom Config:
     ```nginx
     location / {
       proxy_pass http://172.18.0.5:5000;
       limit_req zone=api_limit burst=20 nodelay;
       limit_req_status 429;
     }
     ```

**Teste Mail-Zugriff:** https://mail.trust.it (sollte Mailcow-Login zeigen)

---

## PHASE 5: MOTHERSHIP ROOT API

### 5.1 API-Entwicklung

```bash
# Verzeichnis erstellen
mkdir -p /opt/mothership-api
cd /opt/mothership-api

# Python Virtual Environment
python3 -m venv venv
source venv/bin/activate

# Dependencies installieren
cat > requirements.txt << 'EOF'
fastapi==0.110.0
uvicorn[standard]==0.27.1
python-docker==7.0.0
requests==2.31.0
pydantic[email]==2.6.1
python-dotenv==1.0.1
httpx==0.26.0
EOF

pip install -r requirements.txt

# API-Code erstellen
nano app.py
```

**Füge folgenden Code ein (gekürzte Version, siehe Haupt-Dokument für vollständig):**

```python
from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel, EmailStr
import docker
import requests
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Mothership API", version="1.0.0")

MAILCOW_API_URL = os.getenv("MAILCOW_API_URL")
MAILCOW_API_KEY = os.getenv("MAILCOW_API_KEY")
API_SECRET_KEY = os.getenv("API_SECRET_KEY")

docker_client = docker.from_env()

async def verify_api_key(authorization: str = Header(...)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Invalid auth header")
    token = authorization.split(" ")[1]
    if token != API_SECRET_KEY:
        raise HTTPException(403, "Invalid API key")
    return token

class MailboxCreate(BaseModel):
    address: EmailStr
    domain: str
    quota_gb: int = 10

@app.get("/")
async def root():
    return {"service": "Mothership API", "version": "1.0.0"}

@app.get("/health")
async def health():
    try:
        docker_client.ping()
        return {"status": "healthy"}
    except:
        raise HTTPException(503, "Docker unreachable")

@app.post("/deploy/mailbox")
async def deploy_mailbox(
    mailbox: MailboxCreate,
    api_key: str = Depends(verify_api_key)
):
    local_part = mailbox.address.split('@')[0]
    
    response = requests.post(
        f"{MAILCOW_API_URL}/add/mailbox",
        headers={"X-API-Key": MAILCOW_API_KEY},
        json={
            "local_part": local_part,
            "domain": mailbox.domain,
            "quota": mailbox.quota_gb * 1024,
            "password": "auto-generated-secure-password",
            "password2": "auto-generated-secure-password",
            "active": "1"
        }
    )
    
    if response.status_code != 200:
        raise HTTPException(response.status_code, response.text)
    
    return {
        "success": True,
        "address": mailbox.address,
        "message": "Mailbox created"
    }

# Weitere Endpoints siehe Haupt-Dokument...
```

**Environment-Variablen:**

```bash
cat > .env << 'EOF'
MAILCOW_API_URL=https://mail.trust.it/api/v1
MAILCOW_API_KEY=YOUR-MAILCOW-API-KEY-HERE
API_SECRET_KEY=GENERATE-SECURE-KEY-HERE
EOF

# Sicheren API-Key generieren
openssl rand -base64 32
# Ergebnis in .env eintragen
```

### 5.2 Systemd-Service erstellen

```bash
cat > /etc/systemd/system/mothership-api.service << 'EOF'
[Unit]
Description=Mothership Root API
After=docker.service
Requires=docker.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/mothership-api
EnvironmentFile=/opt/mothership-api/.env
ExecStart=/opt/mothership-api/venv/bin/uvicorn app:app --host 0.0.0.0 --port 5000 --workers 4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Service aktivieren
systemctl daemon-reload
systemctl enable mothership-api
systemctl start mothership-api

# Status prüfen
systemctl status mothership-api

# Logs
journalctl -u mothership-api -f
```

### 5.3 API-Test

```bash
# Health-Check
curl http://localhost:5000/health

# Sollte zurückgeben: {"status":"healthy"}

# Test Mailbox-Erstellung
curl -X POST http://localhost:5000/deploy/mailbox \
  -H "Authorization: Bearer YOUR-API-SECRET-KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "address": "test@trust.it",
    "domain": "trust.it",
    "quota_gb": 10
  }'

# Prüfe in Mailcow-UI ob Mailbox erstellt wurde
```

---

## PHASE 6: KI-INTEGRATION (GEMINI GEM)

### 6.1 Google AI Studio Setup

1. **Account erstellen:** https://makersuite.google.com
2. **API-Key generieren:**
   - Settings → API Keys → Create API Key
   - **Sicher speichern!**

3. **Custom Gem erstellen:**
   - New Chat → Create Gem
   - Name: "Mothership Manager"
   
4. **System-Instructions:**

```
You are the Mothership Infrastructure Agent. You have API access to a 
self-hosted cloud infrastructure.

Your capabilities:
1. Create email mailboxes on custom domains
2. Allocate cloud storage
3. Deploy complete infrastructure templates

IMPORTANT: Always confirm with the user before allocating resources.

After each deployment, provide:
- ✅ Success confirmation
- 🔑 Access credentials
- 📝 Next steps (DNS configuration if needed)
```

### 6.2 API-Integration (Tools & Functions)

**In Google AI Studio → Gem Settings → Tools:**

**Function Definition (JSON):**

```json
{
  "name": "deploy_mailbox",
  "description": "Creates a new email mailbox",
  "parameters": {
    "type": "object",
    "properties": {
      "address": {
        "type": "string",
        "description": "Full email address (e.g., user@domain.com)"
      },
      "domain": {
        "type": "string",
        "description": "Domain name"
      },
      "quota_gb": {
        "type": "integer",
        "description": "Mailbox quota in GB",
        "default": 10
      }
    },
    "required": ["address", "domain"]
  }
}
```

**API Configuration:**

```
Endpoint: https://api.trust.it/deploy/mailbox
Method: POST
Authentication: Bearer Token
Headers:
  Authorization: Bearer YOUR-API-SECRET-KEY
  Content-Type: application/json
```

### 6.3 Test-Interaktion

**Im Gem-Chat:**

```
User: "I need an email address for my business project@mybiz.com"

Gem: [Analysiert Request]
     [Ruft deploy_mailbox API auf]
     
Gem: "✅ Email infrastructure deployed!
     
     📧 Address: project@mybiz.com
     🔑 IMAP: imap.mybiz.com:993
     📤 SMTP: smtp.mybiz.com:465
     🔒 Password: [generiert]
     
     📝 Next: Add these DNS records at your domain registrar:
     
     MX    @    10 mail.trust.it
     A     @    93.184.216.34
     TXT   @    v=spf1 mx ~all"
```

---

## PHASE 7: MONITORING & BACKUP

### 7.1 Prometheus + Grafana

```bash
mkdir -p /opt/monitoring
cd /opt/monitoring

cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  prometheus:
    image: prom/prometheus:latest
    container_name: mothership-prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus-data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
    networks:
      - mothership-private
    restart: unless-stopped

  grafana:
    image: grafana/grafana:latest
    container_name: mothership-grafana
    ports:
      - "3002:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-data:/var/lib/grafana
    networks:
      - mothership-public
    restart: unless-stopped

  node-exporter:
    image: prom/node-exporter:latest
    container_name: mothership-node-exporter
    command:
      - '--path.rootfs=/host'
    volumes:
      - '/:/host:ro,rslave'
    networks:
      - mothership-private
    restart: unless-stopped

volumes:
  prometheus-data:
  grafana-data:

networks:
  mothership-public:
    external: true
  mothership-private:
    external: true
EOF

# Prometheus-Config
cat > prometheus.yml << 'EOF'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'node'
    static_configs:
      - targets: ['mothership-node-exporter:9100']
EOF

# Starten
docker compose up -d

# Grafana-Zugriff: http://YOUR-SERVER-IP:3002
# Login: admin / admin (sofort ändern!)
```

### 7.2 Backup-Automatisierung

```bash
# Backup-Skript erstellen
cat > /opt/mothership/scripts/backup.sh << 'EOF'
#!/bin/bash
set -e

BACKUP_DIR="/mnt/storage-pool/backups"
DATE=$(date +%Y%m%d-%H%M%S)

echo "🔄 Starting backup..."

# ZFS Snapshot
zfs snapshot storage-pool/mail-data@backup-${DATE}
zfs snapshot storage-pool/cloud-storage@backup-${DATE}

# Docker-Volumes
docker run --rm \
  -v mailcow-vmail-vol-1:/source:ro \
  -v ${BACKUP_DIR}:/backup \
  alpine tar czf /backup/mail-${DATE}.tar.gz -C /source .

echo "✅ Backup completed: ${DATE}"
EOF

chmod +x /opt/mothership/scripts/backup.sh

# Cronjob: Täglich um 2 Uhr
echo "0 2 * * * /opt/mothership/scripts/backup.sh >> /var/log/mothership-backup.log 2>&1" | crontab -
```

---

## PHASE 8: PRODUKTION & OPTIMIERUNG

### 8.1 Performance-Tuning

**Kernel-Parameter optimieren:**

```bash
cat >> /etc/sysctl.conf << 'EOF'
# Mothership Performance Tuning
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.ip_local_port_range = 1024 65535
vm.swappiness = 10
EOF

sysctl -p
```

**Docker-Optimierung:**

```bash
cat > /etc/docker/daemon.json << 'EOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2",
  "live-restore": true
}
EOF

systemctl restart docker
```

### 8.2 Security-Audit

```bash
# Lynis Security-Audit installieren
apt install lynis -y

# Audit durchführen
lynis audit system

# Ergebnisse prüfen
cat /var/log/lynis.log
```

### 8.3 Load-Testing

```bash
# Locust installieren
pip3 install locust

# Load-Test-Skript
cat > /opt/mothership/tests/loadtest.py << 'EOF'
from locust import HttpUser, task, between

class MothershipUser(HttpUser):
    wait_time = between(1, 3)
    
    @task
    def health_check(self):
        self.client.get("/health")
    
    @task(3)
    def deploy_mailbox(self):
        self.client.post(
            "/deploy/mailbox",
            headers={"Authorization": "Bearer YOUR-API-KEY"},
            json={
                "address": "test@trust.it",
                "domain": "trust.it",
                "quota_gb": 10
            }
        )
EOF

# Test mit 100 gleichzeitigen Usern
locust -f /opt/mothership/tests/loadtest.py \
  --host=https://api.trust.it \
  --users 100 \
  --spawn-rate 10 \
  --run-time 60s
```

---

## CHECKLISTE: GO-LIVE

```
✅ VPS bestellt & eingerichtet
✅ DNS-Records konfiguriert (inkl. DKIM, SPF, DMARC)
✅ Firewall aktiviert & konfiguriert
✅ Docker & ZFS installiert
✅ Mailcow läuft & erreichbar über HTTPS
✅ Nginx Proxy Manager konfiguriert
✅ SSL-Zertifikate für alle Domains
✅ Mothership API deployed & getestet
✅ Gemini Gem integriert & funktionsfähig
✅ Monitoring aktiv (Grafana erreichbar)
✅ Backup-Cronjob aktiv
✅ Security-Audit durchgeführt
✅ Load-Test erfolgreich (>100 req/s)
✅ Dokumentation vervollständigt
```

---

## TROUBLESHOOTING

### Problem: Mails werden nicht zugestellt

**Diagnose:**
```bash
# Postfix-Queue prüfen
docker exec mailcow-postfix-mailcow postqueue -p

# Logs
docker logs mailcow-postfix-mailcow --tail 100

# DNS-Test
dig MX trust.it +short
dig trust.it +short

# Blacklist-Check
# Besuche: https://mxtoolbox.com/blacklists.aspx
```

**Lösung:**
- Prüfe ob Port 25 beim VPS-Provider offen ist
- Prüfe Reverse-DNS-Eintrag
- Warte auf DNS-Propagation (bis 24h)

### Problem: SSL-Zertifikat schlägt fehl

**Diagnose:**
```bash
# Let's Encrypt Rate-Limits prüfen
# Max 5 Zertifikate pro Woche für dieselbe Domain

# DNS-Auflösung testen
nslookup mail.trust.it 8.8.8.8

# Nginx-Logs
docker logs mothership-proxy
```

**Lösung:**
- Warte bis DNS propagiert ist
- Nutze Staging-Environment von Let's Encrypt für Tests
- Prüfe ob Port 80 & 443 erreichbar sind

### Problem: API gibt 500 Internal Server Error

**Diagnose:**
```bash
# API-Logs
journalctl -u mothership-api -n 100

# Test Mailcow-Connection
curl -H "X-API-Key: YOUR-KEY" \
  https://mail.trust.it/api/v1/get/status/containers
```

**Lösung:**
- Prüfe .env-Datei (API-Keys korrekt?)
- Restart API: `systemctl restart mothership-api`
- Prüfe Mailcow-API-Status in Web-UI

---

## NEXT STEPS

Nach erfolgreichem Setup:

1. **Weitere Domains hinzufügen:**
   - In Mailcow-UI: Configuration → Domains → Add
   - DNS-Records beim Registrar setzen

2. **Nextcloud installieren** (Cloud-Storage):
   - Siehe separates Dokument: `04_NEXTCLOUD_SETUP.md`

3. **Gitea installieren** (Code-Repos):
   - Siehe separates Dokument: `05_GITEA_SETUP.md`

4. **White-Label anbieten:**
   - Pricing festlegen
   - Kunden-Portal entwickeln
   - Billing-Integration (Stripe)

5. **Skalierung:**
   - Multi-Node-Setup mit Docker Swarm
   - Load-Balancer (HAProxy)
   - Geo-Redundanz

---

**Glückwunsch! Ihr Mothership ist einsatzbereit! 🚀**

Bei Fragen: support@trust.it oder Community-Discord
