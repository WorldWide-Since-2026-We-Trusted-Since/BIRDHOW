# MOTHERSHIP: TECHNISCHE ARCHITEKTUR-DIAGRAMME
## Detaillierte System-Visualisierungen & Netzwerk-Topologien

---

## 1. HIGH-LEVEL SYSTEM-ARCHITEKTUR

```
╔══════════════════════════════════════════════════════════════════════╗
║                    MOTHERSHIP CLOUD ECOSYSTEM                         ║
║                                                                       ║
║  ┌─────────────────────────────────────────────────────────────────┐ ║
║  │                      KI-ORCHESTRATOR EBENE                       │ ║
║  │  ┌──────────┐  ┌──────────┐  ┌───────────┐  ┌──────────────┐  │ ║
║  │  │  Gemini  │  │ ChatGPT  │  │  Claude   │  │  Open WebUI  │  │ ║
║  │  │   Gem    │  │   GPT    │  │  Sonnet   │  │   (Local)    │  │ ║
║  │  └────┬─────┘  └────┬─────┘  └─────┬─────┘  └──────┬───────┘  │ ║
║  └───────┼─────────────┼───────────────┼────────────────┼──────────┘ ║
║          │             │               │                │            ║
║          └─────────────┴───────────────┴────────────────┘            ║
║                              │                                        ║
║                              ▼                                        ║
║  ┌─────────────────────────────────────────────────────────────────┐ ║
║  │              MOTHERSHIP ROOT API (FastAPI)                       │ ║
║  │  ┌───────────┐  ┌───────────┐  ┌──────────┐  ┌──────────────┐ │ ║
║  │  │  /deploy  │  │  /status  │  │ /network │  │  /whitecard  │ │ ║
║  │  │  mailbox  │  │ resources │  │ assign-ip│  │   template   │ │ ║
║  │  └───────────┘  └───────────┘  └──────────┘  └──────────────┘ │ ║
║  │                                                                  │ ║
║  │  Authentication: Bearer Token | Rate Limit: 100/min             │ ║
║  └────────────────────────┬─────────────────────────────────────────┘ ║
║                           │                                           ║
║           ┌───────────────┼───────────────┬───────────────────┐      ║
║           │               │               │                   │      ║
║           ▼               ▼               ▼                   ▼      ║
║  ┌─────────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐║
║  │   DOCKER API    │ │   ZFS API   │ │  MAILCOW    │ │   GITEA     │║
║  │   Container-    │ │  Storage    │ │    API      │ │     API     │║
║  │  Orchestrierung │ │  Management │ │   (Mail)    │ │   (Repos)   │║
║  └─────────────────┘ └─────────────┘ └─────────────┘ └─────────────┘║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝

                               ▼

╔══════════════════════════════════════════════════════════════════════╗
║                       CONTAINER-EBENE (LAYER)                         ║
║                                                                       ║
║   ┌───────────────────┐  ┌───────────────────┐  ┌─────────────────┐ ║
║   │     LAYER 1       │  │     LAYER 2       │  │    LAYER 3      │ ║
║   │  MAIL INFRA       │  │  CONTROL PLANE    │  │   SERVICES      │ ║
║   │                   │  │                   │  │                 │ ║
║   │  ┌────────────┐   │  │  ┌────────────┐  │  │  ┌────────────┐│ ║
║   │  │  Mailcow   │   │  │  │   Nginx    │  │  │  │ Nextcloud  ││ ║
║   │  │  Postfix   │   │  │  │   Proxy    │  │  │  │  (1TB)     ││ ║
║   │  │  Dovecot   │   │  │  │   Manager  │  │  │  └────────────┘│ ║
║   │  │  Redis     │   │  │  └────────────┘  │  │                 │ ║
║   │  │  MariaDB   │   │  │                  │  │  ┌────────────┐│ ║
║   │  └────────────┘   │  │  ┌────────────┐  │  │  │   Gitea    ││ ║
║   │                   │  │  │  Open      │  │  │  │  (Repos)   ││ ║
║   │  IP: 172.18.0.10  │  │  │  WebUI     │  │  │  └────────────┘│ ║
║   │  Port: 25,587,993 │  │  └────────────┘  │  │                 │ ║
║   │                   │  │                  │  │  IP: 172.18.0.30│ ║
║   │  Volume:          │  │  IP: 172.18.0.20 │  │  Volume:        │ ║
║   │  /mail-data       │  │  Port: 80, 443   │  │  /cloud-storage │ ║
║   └───────────────────┘  └───────────────────┘  └─────────────────┘ ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝

                               ▼

╔══════════════════════════════════════════════════════════════════════╗
║                        STORAGE-EBENE (VOLUMES)                        ║
║                                                                       ║
║              ┌────────────────────────────────────┐                  ║
║              │    ZFS STORAGE POOL (1TB+)         │                  ║
║              │    /mnt/storage-pool               │                  ║
║              │                                    │                  ║
║              │  ┌──────────────────────────────┐ │                  ║
║              │  │  Dataset: mail-data          │ │                  ║
║              │  │  Compression: lz4            │ │                  ║
║              │  │  Quota: 250GB                │ │                  ║
║              │  │  Snapshots: Täglich          │ │                  ║
║              │  └──────────────────────────────┘ │                  ║
║              │                                    │                  ║
║              │  ┌──────────────────────────────┐ │                  ║
║              │  │  Dataset: cloud-storage      │ │                  ║
║              │  │  Compression: lz4            │ │                  ║
║              │  │  Quota: 500GB                │ │                  ║
║              │  │  Deduplizierung: On          │ │                  ║
║              │  └──────────────────────────────┘ │                  ║
║              │                                    │                  ║
║              │  ┌──────────────────────────────┐ │                  ║
║              │  │  Dataset: docker-volumes     │ │                  ║
║              │  │  Quota: 50GB                 │ │                  ║
║              │  └──────────────────────────────┘ │                  ║
║              │                                    │                  ║
║              │  ┌──────────────────────────────┐ │                  ║
║              │  │  Dataset: backups            │ │                  ║
║              │  │  Quota: 200GB                │ │                  ║
║              │  │  Retention: 30 Tage          │ │                  ║
║              │  └──────────────────────────────┘ │                  ║
║              └────────────────────────────────────┘                  ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝

                               ▼

╔══════════════════════════════════════════════════════════════════════╗
║                    PHYSISCHE INFRASTRUKTUR                            ║
║                                                                       ║
║  ┌─────────────────────────────────────────────────────────────────┐ ║
║  │                 VPS / BARE METAL SERVER                          │ ║
║  │                                                                  │ ║
║  │  CPU: 8 vCores (AMD EPYC / Intel Xeon)                         │ ║
║  │  RAM: 16 GB DDR4                                                │ ║
║  │  Storage: 1 TB NVMe SSD                                         │ ║
║  │  Network: 1 Gbit/s (unmetered)                                 │ ║
║  │  OS: Ubuntu 22.04 LTS                                           │ ║
║  │                                                                  │ ║
║  │  Location: EU (Frankfurt / Amsterdam)                           │ ║
║  │  Provider: Hetzner / Contabo / OVH                              │ ║
║  │  Cost: ~€20-50/Monat                                            │ ║
║  └─────────────────────────────────────────────────────────────────┘ ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
```

---

## 2. NETZWERK-TOPOLOGIE

```
INTERNET
    │
    │ HTTPS/HTTP
    │ Port 80/443
    ▼
┌──────────────────────────────────────────────────────────────────┐
│               REVERSE PROXY (Nginx Proxy Manager)                │
│                                                                   │
│  SSL Termination: Let's Encrypt (Wildcard *.trust.it)           │
│  Rate Limiting: 100 req/min per IP                               │
│  DDoS Protection: CloudFlare Integration                         │
│  WAF: ModSecurity Rules                                          │
│                                                                   │
│  Routing-Regeln:                                                 │
│  • mail.trust.it      → 172.18.0.10:8080 (Mailcow WebUI)       │
│  • api.trust.it       → 172.18.0.5:5000 (Mothership API)       │
│  • cloud.trust.it     → 172.18.0.30:80 (Nextcloud)             │
│  • git.trust.it       → 172.18.0.40:3000 (Gitea)               │
│                                                                   │
│  External IP: 93.184.216.34                                      │
└───────────────────┬──────────────────────────────────────────────┘
                    │
        ┌───────────┴──────────┬─────────────────┐
        │                      │                 │
        ▼                      ▼                 ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│  PUBLIC NETWORK  │  │ PRIVATE NETWORK  │  │  MAIL NETWORK    │
│  172.18.0.0/24   │  │  172.19.0.0/24   │  │  172.20.0.0/24   │
│                  │  │                  │  │                  │
│  Internet-       │  │  Internal-only   │  │  Mail-specific   │
│  zugänglich      │  │  No external     │  │  Isolated        │
│                  │  │  access          │  │                  │
└──────┬───────────┘  └─────┬────────────┘  └─────┬────────────┘
       │                    │                      │
       │                    │                      │
   ┌───┴───────────────┬────┴──────────┬──────────┴──────┐
   │                   │               │                  │
   ▼                   ▼               ▼                  ▼
┌─────────┐      ┌──────────┐   ┌──────────┐      ┌──────────┐
│  Nginx  │      │Mothership│   │ MariaDB  │      │ Postfix  │
│  Proxy  │      │   API    │   │ (Mailcow)│      │ (SMTP)   │
│         │      │          │   │          │      │          │
│ .0.2    │      │   .0.5   │   │  .19.10  │      │  .20.10  │
└─────────┘      └──────────┘   └──────────┘      └──────────┘

   ▼                   ▼               ▼                  ▼
┌─────────┐      ┌──────────┐   ┌──────────┐      ┌──────────┐
│Nextcloud│      │ Open     │   │PostgreSQL│      │ Dovecot  │
│ (Cloud) │      │ WebUI    │   │ (Gitea)  │      │ (IMAP)   │
│         │      │          │   │          │      │          │
│ .0.30   │      │   .0.20  │   │  .19.20  │      │  .20.11  │
└─────────┘      └──────────┘   └──────────┘      └──────────┘

   ▼                                                       ▼
┌─────────┐                                         ┌──────────┐
│  Gitea  │                                         │  Redis   │
│ (Repos) │                                         │  (Cache) │
│         │                                         │          │
│ .0.40   │                                         │  .20.12  │
└─────────┘                                         └──────────┘


FIREWALL RULES (iptables):

INPUT Chain:
  ┌─────────────────────────────────────────────────┐
  │ Port 22  (SSH)        → ACCEPT (Rate Limited)   │
  │ Port 80  (HTTP)       → ACCEPT → Redirect 443   │
  │ Port 443 (HTTPS)      → ACCEPT                  │
  │ Port 25  (SMTP)       → ACCEPT                  │
  │ Port 587 (Submission) → ACCEPT                  │
  │ Port 465 (SMTPS)      → ACCEPT                  │
  │ Port 993 (IMAPS)      → ACCEPT                  │
  │ All Other            → DROP                     │
  └─────────────────────────────────────────────────┘

FORWARD Chain:
  ┌─────────────────────────────────────────────────┐
  │ Docker Networks      → ACCEPT                   │
  │ Cross-Network       → DENY (except API)        │
  └─────────────────────────────────────────────────┘
```

---

## 3. DATENFLUSS-DIAGRAMME

### 3.1 E-Mail-Deployment Flow

```
USER (via KI-Interface)
    │
    │ "Erstelle info@trust.it mit 20GB Speicher"
    ▼
┌──────────────────────────────────────┐
│  GEMINI GEM / ChatGPT GPT            │
│  Natural Language Processing         │
│                                      │
│  Parsing:                            │
│  • Email: info@trust.it              │
│  • Domain: trust.it                  │
│  • Quota: 20GB                       │
└────────────┬─────────────────────────┘
             │
             │ JSON Request
             │ POST /deploy/mailbox
             │ {
             │   "address": "info@trust.it",
             │   "domain": "trust.it",
             │   "quota_gb": 20
             │ }
             ▼
┌──────────────────────────────────────┐
│  MOTHERSHIP ROOT API                 │
│  FastAPI (172.18.0.5:5000)           │
│                                      │
│  1. Authentifizierung prüfen         │
│  2. Rate Limit prüfen                │
│  3. Domain-Validierung               │
│  4. Quota-Verfügbarkeit prüfen       │
└────────────┬─────────────────────────┘
             │
             │ HTTP POST
             │ X-API-Key: MAILCOW_KEY
             ▼
┌──────────────────────────────────────┐
│  MAILCOW API                         │
│  https://mail.trust.it/api/v1        │
│                                      │
│  /add/mailbox                        │
│  {                                   │
│    "local_part": "info",             │
│    "domain": "trust.it",             │
│    "quota": 20480,                   │
│    "password": "auto-generated",     │
│    "active": 1                       │
│  }                                   │
└────────────┬─────────────────────────┘
             │
             │ Database INSERT
             ▼
┌──────────────────────────────────────┐
│  MARIADB (172.19.0.10)               │
│                                      │
│  INSERT INTO mailbox (...)           │
│  VALUES ('info@trust.it', ...)       │
│                                      │
│  INSERT INTO alias (...)             │
└────────────┬─────────────────────────┘
             │
             │ Volume Write
             ▼
┌──────────────────────────────────────┐
│  ZFS DATASET: mail-data              │
│  /mnt/storage-pool/mail-data         │
│                                      │
│  /trust.it/info/                     │
│  ├── cur/                            │
│  ├── new/                            │
│  └── tmp/                            │
│                                      │
│  Quota: 20GB                         │
└────────────┬─────────────────────────┘
             │
             │ Success Response
             ▼
USER (via KI-Interface)
    │
    │ "✅ Mailbox erstellt!
    │  IMAP: imap.trust.it:993
    │  SMTP: smtp.trust.it:465
    │  Password: kX9p2m..."
    ▼


TIMELINE:
  0ms: User-Request
  10ms: KI-Parsing
  50ms: API-Authentifizierung
  100ms: Mailcow-API-Call
  150ms: Database-Insert
  200ms: Volume-Allokation
  250ms: Response an User
  
  Total: ~250ms
```

### 3.2 Eingehende E-Mail Flow

```
EXTERNAL MAIL SERVER
(z.B. Gmail)
    │
    │ SMTP Connection
    │ Port 25
    ▼
┌──────────────────────────────────────┐
│  POSTFIX (MTA)                       │
│  172.20.0.10:25                      │
│                                      │
│  1. SPF-Check                        │
│  2. DKIM-Verification                │
│  3. Recipient-Validation             │
└────────────┬─────────────────────────┘
             │
             │ Spam-Check
             ▼
┌──────────────────────────────────────┐
│  RSPAMD (Spam-Filter)                │
│  172.20.0.13                         │
│                                      │
│  • Bayesian Filter                   │
│  • RBL-Checks                        │
│  • Score: 2.5 (< 15 = OK)            │
└────────────┬─────────────────────────┘
             │
             │ Virus-Scan
             ▼
┌──────────────────────────────────────┐
│  CLAMAV (Antivirus)                  │
│  172.20.0.14                         │
│                                      │
│  Signature-Check: Clean              │
└────────────┬─────────────────────────┘
             │
             │ Delivery
             ▼
┌──────────────────────────────────────┐
│  DOVECOT (MDA)                       │
│  172.20.0.11                         │
│                                      │
│  LMTP Delivery                       │
│  → /mail-data/trust.it/info/new/     │
└────────────┬─────────────────────────┘
             │
             │ Index-Update
             ▼
┌──────────────────────────────────────┐
│  DOVECOT INDEX                       │
│                                      │
│  dovecot.index.cache updated         │
└────────────┬─────────────────────────┘
             │
             │ Push-Notification
             ▼
USER'S MAIL CLIENT
(Thunderbird / Outlook / Mobile)
    │
    │ "Neue Mail von Gmail"
    ▼
```

---

## 4. KI-INTEGRATION ARCHITEKTUR

```
╔═══════════════════════════════════════════════════════════════════════╗
║                      KI-ORCHESTRIERUNG SCHICHTEN                       ║
╚═══════════════════════════════════════════════════════════════════════╝

┌───────────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE EBENE                            │
│                                                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │
│  │   Browser    │  │    Mobile    │  │   Discord    │  │  Slack   │ │
│  │   Web-UI     │  │     App      │  │     Bot      │  │   Bot    │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────┬─────┘ │
│         │                 │                 │               │        │
└─────────┼─────────────────┼─────────────────┼───────────────┼────────┘
          │                 │                 │               │
          └─────────────────┴─────────────────┴───────────────┘
                                     │
                                     ▼
┌───────────────────────────────────────────────────────────────────────┐
│                        KI-PROVIDER EBENE                               │
│                                                                        │
│  ┌──────────────────┐        ┌──────────────────┐                    │
│  │  CLOUD KI        │        │  SELF-HOSTED KI  │                    │
│  │                  │        │                  │                    │
│  │  ┌────────────┐  │        │  ┌────────────┐ │                    │
│  │  │  Gemini    │  │        │  │  Ollama    │ │                    │
│  │  │  (Google)  │  │        │  │  Llama 3   │ │                    │
│  │  └────────────┘  │        │  └────────────┘ │                    │
│  │                  │        │                  │                    │
│  │  ┌────────────┐  │        │  ┌────────────┐ │                    │
│  │  │  ChatGPT   │  │        │  │ Open WebUI │ │                    │
│  │  │  (OpenAI)  │  │        │  │  Frontend  │ │                    │
│  │  └────────────┘  │        │  └────────────┘ │                    │
│  │                  │        │                  │                    │
│  │  ┌────────────┐  │        │  172.18.0.20    │                    │
│  │  │  Claude    │  │        │                  │                    │
│  │  │ (Anthropic)│  │        │                  │                    │
│  │  └────────────┘  │        │                  │                    │
│  │                  │        │                  │                    │
│  └──────────────────┘        └──────────────────┘                    │
│                                                                        │
│  Function/Tool-Definitions:                                           │
│  • OpenAPI 3.1 Spec                                                   │
│  • JSON Schema für Parameter                                          │
│  • Authentication: Bearer Token                                       │
│                                                                        │
└────────────────────────────┬───────────────────────────────────────────┘
                             │
                             │ HTTPS POST
                             │ Authorization: Bearer API_KEY
                             │
                             ▼
┌───────────────────────────────────────────────────────────────────────┐
│                   MOTHERSHIP ROOT API GATEWAY                          │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐│
│  │  API-Endpoint: https://api.mothership.yourdomain.com              ││
│  │                                                                    ││
│  │  Middleware-Stack:                                                ││
│  │  1. ✓ CORS-Handler                                                ││
│  │  2. ✓ Rate-Limiter (100 req/min)                                  ││
│  │  3. ✓ JWT/Bearer-Token-Validator                                  ││
│  │  4. ✓ Request-Logger (Audit-Trail)                                ││
│  │  5. ✓ Input-Sanitizer                                             ││
│  │  6. ✓ Response-Formatter                                          ││
│  └──────────────────────────────────────────────────────────────────┘│
│                                                                        │
│  Available Functions:                                                 │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │  POST /deploy/mailbox      → Erstelle E-Mail-Postfach          │  │
│  │  POST /deploy/storage      → Allokiere Cloud-Speicher          │  │
│  │  POST /deploy/domain       → Registriere neue Domain           │  │
│  │  POST /deploy/whitecard    → Full-Stack-Deployment             │  │
│  │  GET  /status/resources    → System-Status abrufen             │  │
│  │  GET  /status/health       → Health-Check                      │  │
│  │  POST /network/assign-ip   → IP-Zuweisung                      │  │
│  │  POST /ssl/issue           → SSL-Zertifikat generieren         │  │
│  └────────────────────────────────────────────────────────────────┘  │
└────────────────────────────┬───────────────────────────────────────────┘
                             │
                             │ Internal API-Calls
                             │
         ┌───────────────────┼───────────────────┬───────────────┐
         │                   │                   │               │
         ▼                   ▼                   ▼               ▼
┌─────────────────┐  ┌─────────────┐  ┌──────────────┐  ┌───────────┐
│  DOCKER API     │  │  ZFS CLI    │  │  MAILCOW API │  │ GITEA API │
│  Container-Mgmt │  │  Storage    │  │  Mail-Server │  │  Git-Repos│
│  172.18.0.x     │  │  /dev/zfs   │  │  :8080/api   │  │  :3000/api│
└─────────────────┘  └─────────────┘  └──────────────┘  └───────────┘


BEISPIEL-INTERAKTION:

User → KI:
  "I need a professional email setup for mycompany.com with 100GB storage"

KI → API:
  POST https://api.mothership.yourdomain.com/deploy/whitecard
  {
    "template_type": "mail",
    "customer_id": "mycompany",
    "domains": ["mycompany.com"],
    "storage_gb": 100
  }

API → Orchestrator:
  1. Check resources (/status/resources)
  2. Assign IP (172.18.0.45)
  3. Create mailbox (admin@mycompany.com)
  4. Allocate storage (100GB ZFS dataset)
  5. Issue SSL (Let's Encrypt *.mycompany.com)
  6. Configure DNS (return instructions)

API → KI:
  {
    "success": true,
    "mailbox": "admin@mycompany.com",
    "credentials": {...},
    "storage": "100GB allocated",
    "ssl": "Issued and active",
    "next_steps": "Add DNS records..."
  }

KI → User:
  "✅ Your email infrastructure is ready!
  
  📧 Admin Mailbox: admin@mycompany.com
  💾 Storage: 100GB
  🔒 SSL: Active (*.mycompany.com)
  
  📝 Next: Add these DNS records at your registrar..."
```

---

## 5. STORAGE-ARCHITEKTUR (ZFS-POOL)

```
╔═══════════════════════════════════════════════════════════════════╗
║                   ZFS STORAGE POOL ARCHITEKTUR                     ║
╚═══════════════════════════════════════════════════════════════════╝

PHYSICAL LAYER:
┌────────────────────────────────────────────────────────────────┐
│  /dev/sdb (1TB NVMe SSD)                                        │
│  Model: Samsung 980 PRO                                         │
│  Interface: NVMe PCIe 4.0 x4                                    │
│  IOPS: 1M Read / 1M Write                                       │
│  Endurance: 600 TBW                                             │
└────────────────────────────────────────────────────────────────┘
                             │
                             │ ZFS Pool erstellen
                             │ zpool create storage-pool /dev/sdb
                             ▼
┌────────────────────────────────────────────────────────────────┐
│             ZPOOL: storage-pool (Root)                          │
│                                                                 │
│  Eigenschaften:                                                 │
│  • Compression: lz4 (2-3x Space-Saving)                        │
│  • Atime: off (Performance)                                    │
│  • Deduplication: off (RAM-intensiv)                           │
│  • Checksum: sha256 (Integrity)                                │
│  • Copies: 1 (kein RAID)                                       │
│                                                                 │
│  Gesamt-Kapazität: 931 GB (1TB raw)                            │
│  Verwendbar: ~850 GB (nach Overhead)                           │
└────┬───────────────────────────────────────────────────────────┘
     │
     ├─────────────────────────────────────────────────────────┐
     │                                                          │
     ▼                                                          ▼
┌──────────────────────────────┐      ┌──────────────────────────────┐
│  DATASET: mail-data          │      │  DATASET: cloud-storage      │
│  /mnt/storage-pool/mail-data │      │  /mnt/storage-pool/cloud     │
│                              │      │                              │
│  Quota: 250 GB               │      │  Quota: 500 GB               │
│  Reservation: 50 GB          │      │  Reservation: 100 GB         │
│  Compression-Ratio: 2.1x     │      │  Compression-Ratio: 1.8x     │
│  Verwendet: 120 GB (48%)     │      │  Verwendet: 300 GB (60%)     │
│                              │      │                              │
│  Snapshots:                  │      │  Snapshots:                  │
│  • @daily-20260501           │      │  • @weekly-20260428          │
│  • @daily-20260502           │      │  • @monthly-20260401         │
│  • @daily-20260503 (neuest)  │      │                              │
│                              │      │  Deduplizierung: On          │
│  Mount: /var/vmail           │      │  Mount: /nextcloud/data      │
└──────────────┬───────────────┘      └──────────────┬───────────────┘
               │                                     │
               │                                     │
     ┌─────────┴──────────┬──────────────────────────┘
     │                    │
     ▼                    ▼
┌──────────────────────────────┐      ┌──────────────────────────────┐
│  DATASET: git-repos          │      │  DATASET: docker-volumes     │
│  /mnt/storage-pool/git       │      │  /mnt/storage-pool/docker    │
│                              │      │                              │
│  Quota: 50 GB                │      │  Quota: 50 GB                │
│  Verwendet: 15 GB (30%)      │      │  Verwendet: 30 GB (60%)      │
│                              │      │                              │
│  Snapshots:                  │      │  Snapshots:                  │
│  • @pre-upgrade-20260428     │      │  • @backup-20260503          │
│                              │      │                              │
│  Mount: /gitea/repos         │      │  Mount: /var/lib/docker/vol  │
└──────────────────────────────┘      └──────────────────────────────┘


HIERARCHISCHE STRUKTUR:

storage-pool/
├── mail-data/                    [250 GB Quota]
│   ├── trust.it/
│   │   ├── info/                 [20 GB]
│   │   │   ├── cur/
│   │   │   ├── new/
│   │   │   └── tmp/
│   │   ├── support/              [10 GB]
│   │   └── admin/                [50 GB]
│   ├── trust.ch/                 (Alias zu trust.it)
│   └── trust.eu/                 (Alias zu trust.it)
│
├── cloud-storage/                [500 GB Quota]
│   ├── customer-001/             [100 GB]
│   │   ├── files/
│   │   ├── photos/
│   │   └── documents/
│   ├── customer-002/             [200 GB]
│   └── internal/                 [50 GB]
│
├── git-repos/                    [50 GB Quota]
│   ├── mothership-core.git/
│   ├── customer-projects.git/
│   └── documentation.git/
│
├── docker-volumes/               [50 GB Quota]
│   ├── mailcow-redis-vol/
│   ├── mailcow-db-vol/
│   ├── nextcloud-db-vol/
│   └── gitea-db-vol/
│
└── backups/                      [100 GB Quota]
    ├── daily/
    │   ├── mothership-20260501.tar.gz
    │   ├── mothership-20260502.tar.gz
    │   └── mothership-20260503.tar.gz
    └── weekly/
        └── mothership-week18-2026.tar.gz


SNAPSHOT-STRATEGIE:

┌────────────────────────────────────────────────────────────┐
│  Automatisches Snapshot-Management                          │
│                                                             │
│  Häufigkeit:                                                │
│  • Stündlich: Letzte 24 behalten                           │
│  • Täglich: Letzte 7 behalten                              │
│  • Wöchentlich: Letzte 4 behalten                          │
│  • Monatlich: Letzte 12 behalten                           │
│                                                             │
│  Skript: /opt/mothership/scripts/zfs-auto-snapshot.sh      │
│  Cron: */5 * * * * (alle 5 Minuten prüfen)                │
│                                                             │
│  Rollback-Befehl:                                           │
│  zfs rollback storage-pool/mail-data@daily-20260501        │
│                                                             │
│  Snapshot-Größe (Delta):                                    │
│  • Durchschnittlich 5-10% des Dataset-Volumens            │
│  • Bei Compression: Noch geringer                          │
└────────────────────────────────────────────────────────────┘


PERFORMANCE-MONITORING:

┌────────────────────────────────────────────────────────────┐
│  zpool iostat -v 1                                          │
│                                                             │
│                    capacity operations  bandwidth           │
│  pool              alloc   used  read write  read  write    │
│  ────────────────  ─────  ────  ──── ─────  ────  ─────    │
│  storage-pool      680G   700G    45   120   5M    15M      │
│    /dev/sdb        680G   700G    45   120   5M    15M      │
│  ────────────────  ─────  ────  ──── ─────  ────  ─────    │
│                                                             │
│  ARC (Cache):                                               │
│  • Size: 8 GB                                               │
│  • Hit Rate: 95%                                            │
│  • Miss Rate: 5%                                            │
│                                                             │
│  L2ARC (optional SSD-Cache):                                │
│  • Nicht konfiguriert (Single-Drive-Setup)                 │
└────────────────────────────────────────────────────────────┘
```

---

## 6. SECURITY-ARCHITEKTUR

```
╔═══════════════════════════════════════════════════════════════════╗
║                      SECURITY-LAYERS (Defense in Depth)            ║
╚═══════════════════════════════════════════════════════════════════╝

LAYER 1: NETZWERK-PERIMETER
┌──────────────────────────────────────────────────────────────────┐
│  CLOUDFLARE (optional)                                            │
│  • DDoS-Mitigation (Layer 3/4/7)                                 │
│  • WAF-Regeln (OWASP Top 10)                                     │
│  • Rate-Limiting (10k req/min)                                   │
│  • Bot-Protection                                                │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  FIREWALL (iptables / nftables)                                  │
│                                                                  │
│  Default Policy: DROP ALL                                        │
│                                                                  │
│  Allowed Inbound:                                                │
│  • 22/tcp   (SSH)         → Rate-Limited (4 conn/min)           │
│  • 80/tcp   (HTTP)        → Redirect to 443                     │
│  • 443/tcp  (HTTPS)       → ACCEPT                              │
│  • 25/tcp   (SMTP)        → ACCEPT                              │
│  • 465/tcp  (SMTPS)       → ACCEPT                              │
│  • 587/tcp  (Submission)  → ACCEPT                              │
│  • 993/tcp  (IMAPS)       → ACCEPT                              │
│                                                                  │
│  Blocked:                                                        │
│  • 3306/tcp (MySQL)       → DROP (internal-only)                │
│  • 5432/tcp (PostgreSQL)  → DROP (internal-only)                │
│  • 6379/tcp (Redis)       → DROP (internal-only)                │
│  • 5000/tcp (API-direct)  → DROP (via Proxy-only)               │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         ▼

LAYER 2: REVERSE PROXY
┌──────────────────────────────────────────────────────────────────┐
│  NGINX PROXY MANAGER                                             │
│                                                                  │
│  Security-Headers:                                               │
│  • Strict-Transport-Security: max-age=31536000                  │
│  • X-Frame-Options: DENY                                        │
│  • X-Content-Type-Options: nosniff                              │
│  • Content-Security-Policy: default-src 'self'                  │
│  • X-XSS-Protection: 1; mode=block                              │
│                                                                  │
│  SSL/TLS:                                                        │
│  • TLS 1.2, 1.3 only                                            │
│  • Cipher: ECDHE+AESGCM, ECDHE+CHACHA20                         │
│  • Certificate: Let's Encrypt (ECDSA)                           │
│  • OCSP Stapling: Enabled                                       │
│  • HSTS Preload: Submitted                                      │
│                                                                  │
│  Rate-Limiting:                                                  │
│  • /api/*: 100 req/min per IP                                   │
│  • /login: 5 req/min per IP                                     │
│  • Burst: 20                                                    │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         ▼

LAYER 3: APPLICATION-SECURITY
┌──────────────────────────────────────────────────────────────────┐
│  MOTHERSHIP ROOT API                                             │
│                                                                  │
│  Authentication:                                                 │
│  • Bearer Token (SHA-256)                                       │
│  • Token-Rotation: 30 Tage                                      │
│  • API-Key-Storage: Hashicorp Vault                             │
│                                                                  │
│  Authorization:                                                  │
│  • RBAC (Role-Based Access Control)                             │
│    - admin: Full-Access                                         │
│    - user: Limited to own resources                             │
│    - readonly: GET-only                                         │
│                                                                  │
│  Input-Validation:                                               │
│  • Pydantic-Models (Type-Safe)                                  │
│  • Email-Validation (RFC 5322)                                  │
│  • SQL-Injection-Prevention (Parameterized Queries)             │
│  • XSS-Prevention (HTML-Escaping)                               │
│                                                                  │
│  Audit-Logging:                                                  │
│  • Alle API-Calls → /var/log/mothership/audit.log              │
│  • Format: JSON                                                 │
│  • Retention: 90 Tage                                           │
│  • Fields: timestamp, user, action, resource, result            │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         ▼

LAYER 4: CONTAINER-ISOLATION
┌──────────────────────────────────────────────────────────────────┐
│  DOCKER SECURITY                                                 │
│                                                                  │
│  User-Namespaces:                                                │
│  • userns-remap: default                                        │
│  • Container-Root ≠ Host-Root                                   │
│                                                                  │
│  AppArmor-Profile:                                               │
│  • Deny /proc write                                             │
│  • Deny /sys write (außer /sys/fs/cgroup)                       │
│  • Restrict mount                                               │
│                                                                  │
│  Seccomp-Profile:                                                │
│  • Blocked Syscalls: ptrace, reboot, mount                      │
│                                                                  │
│  Capabilities:                                                   │
│  • Dropped: ALL                                                 │
│  • Added: NET_BIND_SERVICE (nur Mail-Container)                 │
│                                                                  │
│  Read-Only-Rootfs:                                               │
│  • Aktiviert für statische Container                            │
│  • Writable-Volumes: /tmp, /var/log                             │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         ▼

LAYER 5: DATA-ENCRYPTION
┌──────────────────────────────────────────────────────────────────┐
│  VERSCHLÜSSELUNG                                                 │
│                                                                  │
│  In-Transit:                                                     │
│  • HTTPS: TLS 1.2+                                              │
│  • SMTP: STARTTLS (mandatory)                                   │
│  • IMAP: SSL/TLS                                                │
│  • API: HTTPS-only                                              │
│                                                                  │
│  At-Rest:                                                        │
│  • ZFS: Native Encryption (aes-256-gcm)                         │
│    Befehl: zfs create -o encryption=on storage-pool/sensitive   │
│  • Backups: GPG-verschlüsselt (RSA 4096-bit)                    │
│                                                                  │
│  Key-Management:                                                 │
│  • Master-Key: Hashicorp Vault                                  │
│  • Key-Rotation: Quartal                                        │
│  • Backup-Keys: Offline-Storage (USB Stick, verschlüsselt)      │
└──────────────────────────────────────────────────────────────────┘


INCIDENT-RESPONSE:

┌──────────────────────────────────────────────────────────────────┐
│  MONITORING & ALERTING                                           │
│                                                                  │
│  Fail2Ban:                                                       │
│  • SSH: 3 Failed-Attempts → 10 Min Ban                          │
│  • API: 10 Failed-Auth → 1 Hour Ban                             │
│  • Mail: 5 Auth-Failures → 30 Min Ban                           │
│                                                                  │
│  SIEM (Security Information Event Management):                   │
│  • Tool: Wazuh (Open-Source)                                    │
│  • Log-Sources: Syslog, Docker, Audit-Logs                      │
│  • Rules: MITRE ATT&CK Framework                                │
│                                                                  │
│  Alerts:                                                         │
│  • Critical: SMS + Email + PagerDuty                            │
│  • Warning: Email                                               │
│  • Info: Dashboard-only                                         │
│                                                                  │
│  Beispiel-Trigger:                                               │
│  • 10+ Failed-Logins in 1 Minute → Critical                     │
│  • New Admin-User created → Warning                             │
│  • Storage > 90% Full → Warning                                 │
│  • Container-Restart-Loop → Critical                            │
└──────────────────────────────────────────────────────────────────┘
```

---

## 7. DEPLOYMENT-PIPELINE (CI/CD)

```
╔═══════════════════════════════════════════════════════════════════╗
║                   GITOPS & CI/CD PIPELINE                          ║
╚═══════════════════════════════════════════════════════════════════╝

DEVELOPER
    │
    │ git push origin main
    ▼
┌──────────────────────────────────────────────────────────────────┐
│  GITEA (Self-Hosted Git)                                         │
│  https://git.trust.it                                            │
│                                                                  │
│  Repository: mothership-core                                     │
│  Branch: main                                                    │
│  Commit: fa3b21c "Add new API endpoint"                          │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Webhook Trigger
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  GITEA ACTIONS (CI Runner)                                       │
│  .gitea/workflows/ci-cd.yml                                      │
│                                                                  │
│  STAGE 1: BUILD                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  • Checkout Code                                            │ │
│  │  • Install Dependencies (pip install -r requirements.txt)   │ │
│  │  • Run Linter (flake8, black)                              │ │
│  │  • Run Tests (pytest)                                       │ │
│  │  • Build Docker Image                                       │ │
│  │    docker build -t mothership-api:${GIT_SHA} .             │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  STAGE 2: SECURITY-SCAN                                          │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  • Trivy Vulnerability-Scan                                 │ │
│  │    trivy image mothership-api:${GIT_SHA}                   │ │
│  │  • SAST (Bandit für Python)                                │ │
│  │  • Dependency-Check                                         │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  STAGE 3: INTEGRATION-TESTS                                      │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  • Start Test-Environment (Docker Compose)                  │ │
│  │  • Run API-Tests (pytest-integration)                       │ │
│  │  • Run Load-Tests (locust)                                  │ │
│  │  • Teardown Test-Environment                                │ │
│  └────────────────────────────────────────────────────────────┘ │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ All Checks Passed
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  DOCKER REGISTRY (Self-Hosted)                                   │
│  registry.trust.it                                               │
│                                                                  │
│  docker push registry.trust.it/mothership-api:${GIT_SHA}        │
│  docker tag ... mothership-api:latest                            │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Deploy-Trigger
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  DEPLOYMENT (Staging)                                            │
│                                                                  │
│  Server: staging.mothership.internal                             │
│                                                                  │
│  Steps:                                                          │
│  1. SSH-Connect: ssh deploy@staging.mothership.internal         │
│  2. Pull-Image: docker pull registry.trust.it/...              │
│  3. Stop-Old: docker-compose down                               │
│  4. Start-New: docker-compose up -d                             │
│  5. Health-Check: curl -f https://staging.../health             │
│  6. Smoke-Tests: pytest tests/smoke/                            │
└────────────────────────┬─────────────────────────────────────────┘
                         │
                         │ Manual Approval (für Production)
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  DEPLOYMENT (Production)                                         │
│                                                                  │
│  Server: mothership.yourdomain.com                               │
│                                                                  │
│  Blue-Green-Deployment:                                          │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  1. Deploy zu "Green" (neue Version)                        │ │
│  │  2. Health-Checks                                           │ │
│  │  3. Route 10% Traffic → Green                               │ │
│  │  4. Monitor für 5 Minuten                                   │ │
│  │  5. Route 100% Traffic → Green                              │ │
│  │  6. Shutdown "Blue" (alte Version)                          │ │
│  │  7. Rename Green → Blue (für nächstes Deploy)              │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Rollback-Plan:                                                  │
│  • Bei Fehler in Stage 4: Route 100% → Blue                     │
│  • Time-to-Rollback: < 30 Sekunden                              │
└──────────────────────────────────────────────────────────────────┘
                         │
                         │ Notification
                         ▼
┌──────────────────────────────────────────────────────────────────┐
│  POST-DEPLOYMENT                                                 │
│                                                                  │
│  • Slack-Notification: "🚀 Deployed v1.2.3 to Production"       │
│  • Update Changelog: CHANGELOG.md                                │
│  • Tag Release: git tag v1.2.3                                   │
│  • Update Documentation: docs.mothership.com                     │
│  • Monitoring: Aktiviere Grafana-Alert "New-Deployment"         │
└──────────────────────────────────────────────────────────────────┘


TIMELINE:

00:00 - Developer: git push
00:01 - Gitea: Webhook-Trigger
00:02 - CI: Build-Start
00:05 - CI: Tests-Completed
00:07 - CI: Security-Scan-Completed
00:08 - CI: Image-Pushed zu Registry
00:09 - CD: Deploy zu Staging
00:12 - CD: Staging-Tests OK
00:15 - Manual: Approval für Production
00:16 - CD: Deploy zu Production (Blue-Green)
00:20 - CD: Deployment-Complete

Total: ~20 Minuten (von Push zu Production)
```

---

**Ende des Dokuments: Technische Architektur-Diagramme**

Dieses Dokument enthält detaillierte Visualisierungen der Mothership-Infrastruktur auf allen Ebenen: Von der High-Level-Architektur über Netzwerk-Topologien, Datenflüsse, KI-Integration, Storage-Management, Security-Layers bis hin zur CI/CD-Pipeline.

Alle Diagramme sind als ASCII-Art erstellt und können direkt in der Dokumentation verwendet werden.
