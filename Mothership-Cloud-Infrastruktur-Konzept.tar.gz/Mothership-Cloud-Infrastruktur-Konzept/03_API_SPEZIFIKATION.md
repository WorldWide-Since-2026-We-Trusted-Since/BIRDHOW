# MOTHERSHIP: API-SPEZIFIKATION & ENTWICKLER-DOKUMENTATION
## Vollständige REST-API-Referenz für Entwickler

---

## ÜBERSICHT

Die Mothership Root API ist eine RESTful-Schnittstelle, die vollständige Kontrolle über die Cloud-Infrastruktur ermöglicht. Sie ist das Herzstück der KI-Integration und ermöglicht programmatischen Zugriff auf alle Kernfunktionen.

**Base URL:** `https://api.mothership.yourdomain.com`  
**API-Version:** 1.0.0  
**Protokoll:** HTTPS (TLS 1.2+)  
**Authentifizierung:** Bearer Token  
**Content-Type:** application/json  

---

## AUTHENTIFIZIERUNG

Alle API-Requests erfordern einen Bearer Token im Authorization-Header:

```http
Authorization: Bearer YOUR_API_SECRET_KEY
```

**API-Key generieren:**

```bash
# Manuell
openssl rand -base64 32

# Oder über API (Admin-Endpoint)
POST /auth/keys/generate
{
  "description": "KI-Integration Gemini",
  "expires_at": "2026-12-31T23:59:59Z"
}
```

**Beispiel-Request:**

```bash
curl -X GET https://api.mothership.yourdomain.com/health \
  -H "Authorization: Bearer kX9p2mL4nQ7rT3w..."
```

**Rate-Limiting:**
- Standard: 100 Requests / Minute
- Burst: 20 zusätzliche Requests
- Header: `X-RateLimit-Remaining`, `X-RateLimit-Reset`

---

## ENDPUNKTE

### 1. SYSTEM & HEALTH

#### GET /
**Beschreibung:** API-Info abrufen  
**Authentifizierung:** Nein

**Response:**
```json
{
  "service": "Mothership Root API",
  "version": "1.0.0",
  "status": "operational",
  "documentation": "https://docs.mothership.yourdomain.com"
}
```

---

#### GET /health
**Beschreibung:** System-Health-Check  
**Authentifizierung:** Nein

**Response:**
```json
{
  "status": "healthy",
  "docker": "connected",
  "mailcow": "connected",
  "storage": {
    "available": "650 GB",
    "total": "1 TB"
  },
  "timestamp": "2026-05-03T14:30:00Z"
}
```

**Status-Codes:**
- `200`: Alle Systeme operationell
- `503`: Ein oder mehrere Services nicht erreichbar

---

#### GET /status/resources
**Beschreibung:** Detaillierte Ressourcen-Übersicht  
**Authentifizierung:** Ja

**Response:**
```json
{
  "storage": {
    "pool": "storage-pool",
    "total_gb": 1000,
    "used_gb": 350,
    "available_gb": 650,
    "datasets": {
      "mail-data": {
        "quota_gb": 250,
        "used_gb": 120,
        "compression_ratio": 2.1
      },
      "cloud-storage": {
        "quota_gb": 500,
        "used_gb": 300,
        "compression_ratio": 1.8
      }
    }
  },
  "containers": {
    "running": 12,
    "total": 15,
    "list": [
      {
        "name": "mailcow-postfix-mailcow",
        "status": "running",
        "uptime": "7 days"
      }
    ]
  },
  "docker": {
    "version": "25.0.3",
    "api_version": "1.44"
  },
  "system": {
    "cpu_usage": 15.3,
    "mem_usage": 62.5,
    "load_avg": [0.45, 0.62, 0.71]
  }
}
```

---

### 2. E-MAIL-MANAGEMENT

#### POST /deploy/mailbox
**Beschreibung:** Erstelle neues E-Mail-Postfach  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "address": "user@trust.it",
  "domain": "trust.it",
  "quota_gb": 10,
  "password": "optional-custom-password"
}
```

**Parameter:**

| Feld | Typ | Erforderlich | Beschreibung |
|------|-----|--------------|--------------|
| address | string (email) | Ja | Vollständige E-Mail-Adresse |
| domain | string | Ja | Domain-Name (muss existieren) |
| quota_gb | integer | Nein | Speicher-Kontingent (Default: 10) |
| password | string | Nein | Custom-Passwort (Default: auto-generiert) |

**Response:**
```json
{
  "success": true,
  "address": "user@trust.it",
  "credentials": {
    "imap": "imap.trust.it:993",
    "smtp": "smtp.trust.it:465",
    "username": "user@trust.it",
    "password": "kX9p2mL4nQ7rT3w"
  },
  "quota_mb": 10240,
  "active": true,
  "created_at": "2026-05-03T14:30:00Z",
  "message": "Mailbox created successfully"
}
```

**Fehler-Codes:**
- `400`: Domain existiert nicht oder ungültige E-Mail-Adresse
- `409`: Mailbox existiert bereits
- `507`: Storage-Quota überschritten

---

#### GET /mailbox/{address}
**Beschreibung:** Mailbox-Details abrufen  
**Authentifizierung:** Ja

**Response:**
```json
{
  "address": "user@trust.it",
  "quota_mb": 10240,
  "used_mb": 2340,
  "messages": 1247,
  "active": true,
  "created_at": "2026-01-15T10:00:00Z",
  "last_login": "2026-05-03T12:15:00Z"
}
```

---

#### DELETE /mailbox/{address}
**Beschreibung:** Mailbox löschen  
**Authentifizierung:** Ja  
**⚠️ ACHTUNG:** Unwiderruflich! Alle Mails werden gelöscht.

**Response:**
```json
{
  "success": true,
  "address": "user@trust.it",
  "message": "Mailbox deleted successfully"
}
```

---

#### POST /domain/add
**Beschreibung:** Neue Domain hinzufügen  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "domain": "newdomain.com",
  "max_mailboxes": 100,
  "max_quota_mb": 10240,
  "dkim_selector": "dkim"
}
```

**Response:**
```json
{
  "success": true,
  "domain": "newdomain.com",
  "dkim_public_key": "v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3...",
  "dns_records": [
    {
      "type": "MX",
      "name": "@",
      "value": "10 mail.trust.it",
      "ttl": 3600
    },
    {
      "type": "TXT",
      "name": "@",
      "value": "v=spf1 mx ~all",
      "ttl": 3600
    },
    {
      "type": "TXT",
      "name": "dkim._domainkey",
      "value": "v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3...",
      "ttl": 3600
    }
  ],
  "message": "Domain added. Please configure DNS records."
}
```

---

#### POST /domain/{domain}/alias
**Beschreibung:** Domain-Alias erstellen (für Multi-TLD)  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "alias_domain": "trust.ch",
  "target_domain": "trust.it"
}
```

**Response:**
```json
{
  "success": true,
  "alias_domain": "trust.ch",
  "target_domain": "trust.it",
  "message": "Alias created. Mails to trust.ch will be routed to trust.it"
}
```

---

### 3. STORAGE-MANAGEMENT

#### POST /deploy/storage
**Beschreibung:** Cloud-Speicher allokieren  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "customer_id": "customer-001",
  "size_gb": 100,
  "dedup": true,
  "compression": true
}
```

**Response:**
```json
{
  "success": true,
  "customer_id": "customer-001",
  "dataset": "storage-pool/cloud-storage/customer-001",
  "quota_gb": 100,
  "storage_path": "/mnt/storage-pool/cloud-storage/customer-001",
  "access_url": "https://cloud.trust.it",
  "credentials": {
    "username": "customer-001",
    "password": "auto-generated",
    "webdav_url": "https://cloud.trust.it/remote.php/dav"
  },
  "message": "Storage allocated successfully"
}
```

---

#### GET /storage/{customer_id}/stats
**Beschreibung:** Storage-Statistiken abrufen  
**Authentifizierung:** Ja

**Response:**
```json
{
  "customer_id": "customer-001",
  "quota_gb": 100,
  "used_gb": 45.3,
  "available_gb": 54.7,
  "file_count": 15847,
  "compression_ratio": 1.8,
  "dedup_ratio": 1.2,
  "last_access": "2026-05-03T12:30:00Z"
}
```

---

#### POST /storage/{customer_id}/resize
**Beschreibung:** Storage-Quota anpassen  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "new_quota_gb": 200
}
```

**Response:**
```json
{
  "success": true,
  "customer_id": "customer-001",
  "old_quota_gb": 100,
  "new_quota_gb": 200,
  "message": "Quota updated successfully"
}
```

---

### 4. WHITECARD-TEMPLATES

#### POST /deploy/whitecard
**Beschreibung:** Komplett-Stack deployen  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "template_type": "full",
  "customer_id": "customer-002",
  "domains": ["mybusiness.com", "mybusiness.de"],
  "storage_gb": 250,
  "mail_quota_gb": 20,
  "enable_cloud": true,
  "enable_git": true
}
```

**Template-Typen:**
- `mail`: Nur E-Mail-Infrastruktur
- `storage`: Nur Cloud-Speicher
- `full`: Mail + Storage + Git + Monitoring

**Response:**
```json
{
  "success": true,
  "customer_id": "customer-002",
  "template": "full",
  "deployments": {
    "mail": {
      "domain": "mybusiness.com",
      "mailboxes": [
        {
          "address": "admin@mybusiness.com",
          "credentials": {...}
        }
      ],
      "dkim_configured": true
    },
    "storage": {
      "quota_gb": 250,
      "access_url": "https://cloud.mybusiness.com"
    },
    "git": {
      "url": "https://git.mybusiness.com",
      "admin_user": "gitadmin",
      "admin_password": "auto-generated"
    }
  },
  "dns_records": [...],
  "estimated_setup_time": "5-10 minutes",
  "message": "Whitecard deployment initiated"
}
```

---

### 5. NETZWERK-MANAGEMENT

#### POST /network/assign-ip
**Beschreibung:** IP aus Pool zuweisen  
**Authentifizierung:** Ja (Admin)

**Request-Body:**
```json
{
  "container_name": "customer-app-001",
  "network": "mothership-public",
  "preferred_ip": "172.18.0.50"
}
```

**Response:**
```json
{
  "success": true,
  "container_name": "customer-app-001",
  "assigned_ip": "172.18.0.50",
  "network": "mothership-public",
  "gateway": "172.18.0.1",
  "subnet": "172.18.0.0/24"
}
```

---

#### GET /network/topology
**Beschreibung:** Netzwerk-Übersicht abrufen  
**Authentifizierung:** Ja (Admin)

**Response:**
```json
{
  "networks": [
    {
      "name": "mothership-public",
      "subnet": "172.18.0.0/24",
      "gateway": "172.18.0.1",
      "containers": [
        {
          "name": "mothership-proxy",
          "ip": "172.18.0.2"
        },
        {
          "name": "mothership-api",
          "ip": "172.18.0.5"
        }
      ]
    },
    {
      "name": "mothership-private",
      "subnet": "172.19.0.0/24",
      "internal": true,
      "containers": [...]
    }
  ]
}
```

---

### 6. SSL/TLS-MANAGEMENT

#### POST /ssl/issue
**Beschreibung:** Let's Encrypt Zertifikat generieren  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "domain": "newsite.com",
  "wildcard": true,
  "email": "admin@newsite.com"
}
```

**Response:**
```json
{
  "success": true,
  "domain": "newsite.com",
  "wildcard": true,
  "certificate": {
    "issuer": "Let's Encrypt",
    "valid_from": "2026-05-03T14:00:00Z",
    "valid_until": "2026-08-01T14:00:00Z",
    "serial": "03F4A2...",
    "fingerprint": "SHA256:A1B2C3..."
  },
  "auto_renewal": true,
  "message": "Certificate issued successfully"
}
```

---

### 7. MONITORING & LOGS

#### GET /logs/api
**Beschreibung:** API-Logs abrufen  
**Authentifizierung:** Ja (Admin)

**Query-Parameter:**
- `level`: DEBUG, INFO, WARNING, ERROR
- `limit`: Max. Anzahl Einträge (default: 100)
- `since`: ISO-8601 Timestamp

**Response:**
```json
{
  "logs": [
    {
      "timestamp": "2026-05-03T14:30:15Z",
      "level": "INFO",
      "endpoint": "/deploy/mailbox",
      "method": "POST",
      "user": "api-key-gemini-001",
      "status_code": 200,
      "duration_ms": 245
    },
    {
      "timestamp": "2026-05-03T14:25:00Z",
      "level": "ERROR",
      "endpoint": "/deploy/mailbox",
      "method": "POST",
      "user": "api-key-test-001",
      "status_code": 400,
      "error": "Domain does not exist"
    }
  ],
  "total": 2,
  "next_page": null
}
```

---

#### GET /metrics
**Beschreibung:** Prometheus-Metriken  
**Authentifizierung:** Nein (Internal-Only)  
**Format:** Prometheus Text Format

**Response:**
```
# HELP mothership_api_requests_total Total API requests
# TYPE mothership_api_requests_total counter
mothership_api_requests_total{endpoint="/deploy/mailbox",method="POST"} 1547

# HELP mothership_api_duration_seconds API request duration
# TYPE mothership_api_duration_seconds histogram
mothership_api_duration_seconds_bucket{le="0.1"} 850
mothership_api_duration_seconds_bucket{le="0.5"} 1200

# HELP mothership_storage_used_bytes Storage usage
# TYPE mothership_storage_used_bytes gauge
mothership_storage_used_bytes{dataset="mail-data"} 128849018880
```

---

## WEBHOOKS

Die API kann Events an externe URLs senden (z.B. für Slack-Notifications).

#### POST /webhooks/register
**Beschreibung:** Webhook registrieren  
**Authentifizierung:** Ja

**Request-Body:**
```json
{
  "url": "https://hooks.slack.com/services/...",
  "events": ["mailbox.created", "storage.allocated", "error.critical"],
  "secret": "webhook-secret-for-verification"
}
```

**Response:**
```json
{
  "success": true,
  "webhook_id": "wh_7xK9pL2mN4",
  "url": "https://hooks.slack.com/services/...",
  "events": ["mailbox.created", "storage.allocated", "error.critical"],
  "active": true
}
```

**Webhook-Payload-Beispiel:**
```json
{
  "event": "mailbox.created",
  "timestamp": "2026-05-03T14:30:00Z",
  "data": {
    "address": "newuser@trust.it",
    "quota_gb": 10
  },
  "signature": "sha256=abc123..."
}
```

---

## ERROR-HANDLING

**Standard-Error-Response:**
```json
{
  "error": {
    "code": "MAILBOX_EXISTS",
    "message": "Mailbox user@trust.it already exists",
    "details": {
      "address": "user@trust.it",
      "created_at": "2026-01-15T10:00:00Z"
    },
    "request_id": "req_7xK9pL2mN4"
  }
}
```

**HTTP-Status-Codes:**

| Code | Bedeutung | Beispiel |
|------|-----------|----------|
| 200 | OK | Request erfolgreich |
| 201 | Created | Ressource erstellt |
| 400 | Bad Request | Ungültige Parameter |
| 401 | Unauthorized | Fehlender/ungültiger API-Key |
| 403 | Forbidden | Zugriff verweigert |
| 404 | Not Found | Ressource existiert nicht |
| 409 | Conflict | Ressource existiert bereits |
| 429 | Too Many Requests | Rate-Limit überschritten |
| 500 | Internal Server Error | Server-Fehler |
| 503 | Service Unavailable | Service nicht erreichbar |
| 507 | Insufficient Storage | Speicher voll |

**Error-Codes:**

| Code | Beschreibung |
|------|--------------|
| INVALID_EMAIL | E-Mail-Format ungültig |
| DOMAIN_NOT_FOUND | Domain existiert nicht |
| MAILBOX_EXISTS | Mailbox existiert bereits |
| QUOTA_EXCEEDED | Storage-Quota überschritten |
| RATE_LIMIT_EXCEEDED | Zu viele Requests |
| AUTH_FAILED | Authentifizierung fehlgeschlagen |
| MAILCOW_UNAVAILABLE | Mailcow-API nicht erreichbar |
| DOCKER_ERROR | Docker-Operation fehlgeschlagen |

---

## SDK & CODE-BEISPIELE

### Python (mit requests)

```python
import requests

class MothershipAPI:
    def __init__(self, base_url, api_key):
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def create_mailbox(self, address, domain, quota_gb=10):
        response = requests.post(
            f"{self.base_url}/deploy/mailbox",
            headers=self.headers,
            json={
                "address": address,
                "domain": domain,
                "quota_gb": quota_gb
            }
        )
        response.raise_for_status()
        return response.json()
    
    def get_resources(self):
        response = requests.get(
            f"{self.base_url}/status/resources",
            headers=self.headers
        )
        response.raise_for_status()
        return response.json()

# Verwendung
api = MothershipAPI(
    base_url="https://api.trust.it",
    api_key="YOUR_API_KEY"
)

result = api.create_mailbox(
    address="newuser@trust.it",
    domain="trust.it",
    quota_gb=20
)

print(f"Mailbox created: {result['address']}")
print(f"IMAP: {result['credentials']['imap']}")
```

### Node.js (mit axios)

```javascript
const axios = require('axios');

class MothershipAPI {
  constructor(baseURL, apiKey) {
    this.client = axios.create({
      baseURL,
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    });
  }

  async createMailbox(address, domain, quotaGB = 10) {
    const response = await this.client.post('/deploy/mailbox', {
      address,
      domain,
      quota_gb: quotaGB
    });
    return response.data;
  }

  async getResources() {
    const response = await this.client.get('/status/resources');
    return response.data;
  }
}

// Verwendung
const api = new MothershipAPI(
  'https://api.trust.it',
  'YOUR_API_KEY'
);

(async () => {
  const result = await api.createMailbox(
    'newuser@trust.it',
    'trust.it',
    20
  );
  
  console.log(`Mailbox created: ${result.address}`);
  console.log(`IMAP: ${result.credentials.imap}`);
})();
```

### cURL (Shell-Skripte)

```bash
#!/bin/bash

API_URL="https://api.trust.it"
API_KEY="YOUR_API_KEY"

# Create Mailbox
create_mailbox() {
  local address=$1
  local domain=$2
  local quota=${3:-10}
  
  curl -X POST "${API_URL}/deploy/mailbox" \
    -H "Authorization: Bearer ${API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{
      \"address\": \"${address}\",
      \"domain\": \"${domain}\",
      \"quota_gb\": ${quota}
    }"
}

# Get Resources
get_resources() {
  curl -X GET "${API_URL}/status/resources" \
    -H "Authorization: Bearer ${API_KEY}"
}

# Verwendung
create_mailbox "test@trust.it" "trust.it" 15
```

---

## OPENAPI-SPEZIFIKATION (YAML)

Vollständige OpenAPI 3.1-Spec für Import in Tools wie Postman, Insomnia, Swagger-UI:

```yaml
openapi: 3.1.0
info:
  title: Mothership Root API
  version: 1.0.0
  description: |
    Sovereign Cloud Infrastructure Management API
    
    Features:
    - E-Mail-Management (Mailcow)
    - Storage-Allocation (ZFS)
    - Network-Management (Docker)
    - SSL/TLS-Automation (Let's Encrypt)
    
    Authentication: Bearer Token
    
  contact:
    name: Mothership Support
    email: support@trust.it
    url: https://docs.mothership.yourdomain.com

servers:
  - url: https://api.mothership.yourdomain.com
    description: Production
  - url: https://api-staging.mothership.yourdomain.com
    description: Staging

security:
  - BearerAuth: []

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: API-Key

  schemas:
    MailboxCreate:
      type: object
      required:
        - address
        - domain
      properties:
        address:
          type: string
          format: email
          example: user@trust.it
        domain:
          type: string
          example: trust.it
        quota_gb:
          type: integer
          default: 10
          minimum: 1
          maximum: 1000
        password:
          type: string
          format: password
    
    MailboxResponse:
      type: object
      properties:
        success:
          type: boolean
        address:
          type: string
        credentials:
          type: object
          properties:
            imap:
              type: string
            smtp:
              type: string
            username:
              type: string
            password:
              type: string
        message:
          type: string

paths:
  /health:
    get:
      summary: Health Check
      tags:
        - System
      security: []
      responses:
        '200':
          description: System healthy
          content:
            application/json:
              schema:
                type: object
                properties:
                  status:
                    type: string
                    example: healthy

  /deploy/mailbox:
    post:
      summary: Create Mailbox
      tags:
        - Email
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/MailboxCreate'
      responses:
        '200':
          description: Mailbox created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/MailboxResponse'
        '400':
          description: Invalid request
        '409':
          description: Mailbox already exists
```

---

## RATE-LIMITING & PAGINATION

**Rate-Limit-Headers:**
```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1620057600
```

**Pagination (bei Listen-Endpunkten):**
```http
GET /mailboxes?page=2&limit=50

Response:
{
  "data": [...],
  "pagination": {
    "current_page": 2,
    "per_page": 50,
    "total_pages": 5,
    "total_items": 247,
    "next": "/mailboxes?page=3&limit=50",
    "prev": "/mailboxes?page=1&limit=50"
  }
}
```

---

## VERSIONIERUNG

API-Versionierung über URL-Pfad:

- `https://api.trust.it/v1/deploy/mailbox` (Current)
- `https://api.trust.it/v2/deploy/mailbox` (Future)

**Deprecation-Hinweise:**
```http
Deprecation: true
Sunset: Wed, 01 Jan 2027 00:00:00 GMT
Link: <https://docs.mothership.com/migrations/v1-to-v2>; rel="deprecation"
```

---

## TESTING & SANDBOX

**Sandbox-Umgebung:**
- URL: `https://api-sandbox.mothership.yourdomain.com`
- Keine echten Ressourcen-Allocations
- Test-API-Keys mit Prefix `test_`

**Postman-Collection:**
Download: https://docs.mothership.com/api/mothership-api.postman_collection.json

---

**Ende der API-Spezifikation**

Diese Dokumentation ist als lebendiges Dokument konzipiert und wird bei neuen API-Versionen aktualisiert. Feedback willkommen unter: api-feedback@trust.it
